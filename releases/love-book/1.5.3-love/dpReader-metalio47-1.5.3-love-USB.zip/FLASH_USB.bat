@echo off
setlocal
cd /d "%~dp0"
if exist ".usb-python\Scripts\python.exe" (
  ".usb-python\Scripts\python.exe" -c "import esptool, serial; assert tuple(int(x) for x in esptool.__version__.split('.')[:2]) >= (5, 6)" >nul 2>nul
  if not errorlevel 1 (
    ".usb-python\Scripts\python.exe" flash_usb.py %*
    goto flash_done
  )
)
where py >nul 2>nul
if not errorlevel 1 (
  for %%V in (3.12 3.13 3.11 3.14) do (
    py -%%V -c "import esptool, serial; assert tuple(int(x) for x in esptool.__version__.split('.')[:2]) >= (5, 6)" >nul 2>nul
    if not errorlevel 1 (
      py -%%V flash_usb.py %*
      goto flash_done
    )
  )
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys, esptool, serial; assert sys.version_info[:2] < (3, 15); assert tuple(int(x) for x in esptool.__version__.split('.')[:2]) >= (5, 6)" >nul 2>nul
  if not errorlevel 1 (
    python flash_usb.py %*
    goto flash_done
  )
)
echo Install Python 3.12 from python.org, then run in this folder:
echo py -3.12 -m venv .usb-python
echo .usb-python\Scripts\python.exe -m pip install "esptool==5.6.0"
pause
exit /b 1
:flash_done
set "FLASH_RESULT=%ERRORLEVEL%"
echo.
if not "%FLASH_RESULT%"=="0" echo USB flash failed. Read the error above.
pause
exit /b %FLASH_RESULT%
